package com.cc.test.t6;

/**
 * 大象类
 */
public class Elephant {
    String name;
    double length;
    double height;
    double width;
}
